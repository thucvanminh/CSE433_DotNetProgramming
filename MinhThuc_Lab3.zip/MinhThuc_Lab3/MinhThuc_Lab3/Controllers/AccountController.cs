﻿using Microsoft.AspNetCore.Mvc;

namespace MinhThuc_Lab3.Controllers
{
    public class AccountController : Controller
    {
        public IActionResult Login()
        {
            return View();
        }

        public IActionResult Register()
        {
            return View();
        }
    }
}
